<?php 

	// header('content-type:text');
	header('Content-Type: text/html');
	define("TOKEN", "zhong");
	
	include './wx_sample.php';

	$wechatObj = new wechatCallbackapiTest();
	// $wechatObj->valid();
	$wechatObj->responseMsg();






 ?>